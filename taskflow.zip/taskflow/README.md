# TaskFlow API

A portfolio-ready task management REST API built with **Python, FastAPI, SQLAlchemy and SQLite**.

## Features

- User registration and JWT-based login
- Password hashing (bcrypt)
- Create, read, update and delete tasks
- Task status (`todo`, `in_progress`, `done`)
- Task priority (`low`, `medium`, `high`)
- Optional due dates and descriptions
- Search by title, filter by status/priority
- Pagination
- User data isolation: users can only access their own tasks
- Automatic interactive API documentation
- Automated API tests

## Tech stack

- Python 3.11+
- FastAPI + Uvicorn
- SQLAlchemy 2
- SQLite
- Pydantic
- JWT
- pytest

## Run locally

### 1. Create and activate a virtual environment

**Windows PowerShell**
```powershell
py -3.11 -m venv .venv
.venv\\Scripts\\Activate.ps1
```

If PowerShell blocks activation:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.venv\\Scripts\\Activate.ps1
```

**macOS / Linux**
```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 2. Install dependencies
```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 3. Start the API
```bash
uvicorn app.main:app --reload
```

Open:
- API docs: http://127.0.0.1:8000/docs
- Health check: http://127.0.0.1:8000/health

The SQLite database `taskflow.db` is created automatically on first start.

## Quick start in Swagger

1. Open `/docs`.
2. Expand `POST /auth/register`, click **Try it out**, and register a user:
```json
{
  "username": "jan",
  "email": "jan@example.com",
  "password": "strong-pass-123"
}
```
3. Expand `POST /auth/login`. Enter your username and password in the form fields and execute it.
4. Copy the `access_token` from the response.
5. Click **Authorize** near the top of Swagger and paste the token. Swagger's OAuth2 form may ask for username and password instead; use the same credentials and authorize.
6. Use `POST /tasks` to create a task:
```json
{
  "title": "Learn FastAPI",
  "description": "Build a small REST API",
  "status": "in_progress",
  "priority": "high",
  "due_date": null
}
```
7. Try `GET /tasks`, filters such as `/tasks?status=done`, `PATCH /tasks/{task_id}` and `DELETE /tasks/{task_id}`.

## Run tests

In a second terminal, with the virtual environment activated:
```bash
pytest -v
```

## Main API routes

| Method | Route | Purpose |
|---|---|---|
| POST | `/auth/register` | Create an account |
| POST | `/auth/login` | Get an access token |
| POST | `/tasks` | Create a task |
| GET | `/tasks` | List/filter/search tasks |
| GET | `/tasks/{task_id}` | Get one task |
| PATCH | `/tasks/{task_id}` | Update a task |
| DELETE | `/tasks/{task_id}` | Delete a task |

## Example filters

- `/tasks?status=todo`
- `/tasks?priority=high`
- `/tasks?search=epam`
- `/tasks?page=1&page_size=5`
- `/tasks?status=in_progress&priority=high&page=1&page_size=10`

## Project structure

```text
taskflow/
├── app/
│   ├── routers/
│   │   ├── auth.py
│   │   └── tasks.py
│   ├── database.py
│   ├── dependencies.py
│   ├── main.py
│   ├── models.py
│   ├── schemas.py
│   └── security.py
├── tests/
│   ├── conftest.py
│   └── test_api.py
├── .env.example
├── .gitignore
├── README.md
└── requirements.txt
```

## Good next improvements

- Replace `create_all()` with Alembic migrations
- Add Docker and docker-compose
- Add rate limiting and refresh tokens
- Add integration tests with PostgreSQL
- Add a small frontend
- Add CI with GitHub Actions

## Security note

This is a learning/portfolio project. Before deploying publicly, set a strong secret key via `TASKFLOW_SECRET_KEY`, restrict CORS origins, use HTTPS, add database migrations, and review authentication/security settings.
